import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {JwtHelperService} from '@auth0/angular-jwt';

@Injectable()
export class AuthService {

  constructor(private router: Router) {

  }

  public getToken(): string {
    return localStorage.getItem('auth-token');
  }

  public setToken(token: string) {
    return localStorage.setItem('auth-token', token);
  }

  public isAuthenticated(): boolean {
    // get the token
    const token = this.getToken();
    // return a boolean reflecting
    // whether or not the token is expired
    // return tokenNotExpired(token);
    return true;
  }

  public getUsername(): any {
    const jwtHelper = new JwtHelperService();
    const decodedToken = jwtHelper.decodeToken(this.getToken());
    if (decodedToken) {
      return decodedToken.sub;
    }
    return '';
  }

  public getRoles(): any {
    const jwtHelper = new JwtHelperService();
    const decodedToken = jwtHelper.decodeToken(this.getToken());
    if (decodedToken) {
      if (decodedToken.roles) {
        return decodedToken.roles.split(',');
      } else {
        return [];
      }
    }
    return '';
  }

  public getPermissions(): any {
    const jwtHelper = new JwtHelperService();
    const decodedToken = jwtHelper.decodeToken(this.getToken());
    if (decodedToken) {
      if (decodedToken.roles) {
        return decodedToken.perms.split(',');
      } else {
        return [];
      }
    }
    return '';
  }

  public logout() {
    localStorage.removeItem('auth-token');
    this.router.navigateByUrl('/login');
  }
}
