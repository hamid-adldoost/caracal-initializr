export class Pair {

  key: string;
  value: any;
}
