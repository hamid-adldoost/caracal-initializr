
import {Component, OnInit} from '@angular/core';
import {Route, Router} from '@angular/router';
import {MessageService} from 'primeng/components/common/messageservice';
import {LoginService} from './login.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: any;
  password: any;

  constructor(private loginService: LoginService,
              private router: Router,
              private messageService: MessageService) {
  }

  ngOnInit() {
  }

  submit() {
    this.loginService.login(this.username, this.password).subscribe(res => {
      console.log(res);
      this.router.navigateByUrl('/inner/dashboard');
    }, error => {
      console.log('error', error);
      this.messageService.add({severity: 'error', summary: error.error.message});
    });
  }
}
