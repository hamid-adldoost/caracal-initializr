import { Component, OnInit } from '@angular/core';
import {CustomerService} from './customer.service';
import {QueryOptions} from '../general/query-options';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private customerService: CustomerService) { }

  id: any;
  customerNumber: any;


  items = [];

  ngOnInit() {
    this.customerService.list(new QueryOptions(), 'search').subscribe(res => {
      console.log('list call res', res);
    });
  }

}
