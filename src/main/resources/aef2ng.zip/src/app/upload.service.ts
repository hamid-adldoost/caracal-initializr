import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../environments/environment';
import {QueryOptions} from './general/query-options';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  serviceUrl = `${environment.baseServiceUrl}`;

  constructor(private httpClient: HttpClient) {

  }

  uploadFile(fileData: any, entity: string): Observable<any> {

    const form = new FormData();
    form.append('file', fileData, fileData.name);
    form.append('entity', entity);
    return this.httpClient.post(this.serviceUrl + '/attachment/upload', form);

  }

  findAllAttachments(entity: string, id: any): Observable<any> {
    const options = new QueryOptions();
    options.options = [{key: 'relatedEntity', value: entity}, {key: 'relatedRecordId', value: id}];
    return this.httpClient.get(this.serviceUrl + '/attachment/search?' + `${options.getOptionsQueryString()}`);
  }

  downloadAttachment(id: any): Observable<any> {
    return this.httpClient.get(this.serviceUrl + '/attachment/download/' + id, {observe: 'response', responseType: 'blob'});
  }

  updateAttachmentRecordId(uploadedFileIds: any[], id: any): Observable<any> {
    return this.httpClient.post(this.serviceUrl + '/attachment/set-record-id/' + id, uploadedFileIds);
  }

  deleteAttachment(id: any): Observable<any> {
    return this.httpClient.delete(this.serviceUrl + '/attachment/delete/' + id);
  }
}
