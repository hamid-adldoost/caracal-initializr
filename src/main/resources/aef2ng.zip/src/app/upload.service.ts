import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  serviceUrl = `${environment.baseServiceUrl}`;

  constructor(private httpClient: HttpClient) {

  }

  uploadFile(fileData: any, entity: string): Observable<any> {

    const form = new FormData();
    form.append('file', fileData, fileData.name);
    form.append('entity', entity);
    return this.httpClient.post(this.serviceUrl + '/attachment/upload', form);

  }
}
